class DataSaya {
   static String nama = "Ahirandra Kasmi";
    static String gambar = "assets/gambar_dosen/Ahirandra_Kasmi.jpg";
}
